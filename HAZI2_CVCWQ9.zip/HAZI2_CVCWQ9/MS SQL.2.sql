select * FROM Ugyfel

CREATE user proba without login
grant select on Ugyfel to proba
execute as user='proba'
select * from Ugyfel